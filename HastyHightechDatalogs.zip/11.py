import tkinter as tk
from tkcalendar import Calendar

window = tk.Tk()
window.title('Salons "Tea time" ')
window.geometry("350x350")

f = open("vardi.txt","r")
vardi=[]
for x in open ('vardi.txt','r').readlines():
  vardi.append(x.strip())
f.close()

cal=Calendar(window,selectmode="day",year=2022,month=2,day=3)
cal.place(anchor="c",relx=0.5,rely=0.3)


def display_msg():
  vardi1=[]
  datue = cal.get_date()
  date1=str(datue)
  laiks1=str(sv)
  klients1=str(text.get())
  vardi1.append(f"{date1} {laiks1}")
  print(vardi1)
  if vardi1[0] in vardi:
    slikti=tk.Label(window,text="Aizņemts",bg="#cd950c").place(relx=0.8,rely=0.8)
  else:
    vardi.append(f"{date1} {laiks1}")
    labi=tk.Label(window,text="Pieņemts",bg="#cd950c").place(relx=0.8,rely=0.8)
    vardi1=f"{date1} {laiks1}\n"
    f=open("vardi.txt","a")
    f.write(vardi1)
    f.close()

text = tk.StringVar()
textbox = tk.Entry(window, textvariable=text).place(anchor="c",relx=0.5,rely=0.9)



actionBtn =tk.Button(window,text="Book Appointment",command=display_msg)
actionBtn.place(anchor="c",relx=0.5,rely=0.8)


laiki = ['8:00', '10:00', '12:00', '14:00', '16:00', '18:00']
svar = tk.StringVar()
svar.set(laiki[0])
sv = laiki[0]
def _get(cur):  
  global sv  
  sv = cur          
drop = tk.OptionMenu(window, svar, command = _get, *laiki)
drop.place(anchor="c",relx=0.5,rely=0.65)



tk.mainloop()
