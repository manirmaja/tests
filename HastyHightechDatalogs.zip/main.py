import tkinter as tk
from tkcalendar import Calendar


window = tk.Tk()
window.title('Salons "Tea time" ')
window.geometry("350x350")

def mirdza():
  f = open("vardi.txt","r")
  vardi=[]
  for x in open ('vardi.txt','r').readlines():
    vardi.append(x.strip())
  f.close()

  cal=Calendar(window,selectmode="day",year=2022,month=2,day=3)
  cal.place(anchor="c",relx=0.5,rely=0.3)


  def display_msg():
    vardi1=[]
    datue = cal.get_date()
    date1=str(datue)
    laiks1=str(sv)
    klients1=str(text.get())
    vardi1.append(f"{date1} {laiks1}")
    print(vardi1)
    if vardi1[0] in vardi:
      slikti=tk.Label(window,text="Aizņemts",bg="#cd950c").place(relx=0.8,rely=0.8)
    else:
      vardi.append(f"{date1} {laiks1}")
      labi=tk.Label(window,text="Pieņemts",bg="#cd950c").place(relx=0.8,rely=0.8)
      vardi1=f"{date1} {laiks1}\n"
      f=open("vardi.txt","a")
      f.write(vardi1)
      f.close()

  text = tk.StringVar()
  textbox = tk.Entry(window, textvariable=text).place(anchor="c",relx=0.5,rely=0.9)



  actionBtn =tk.Button(window,text="Book Appointment",command=display_msg)
  actionBtn.place(anchor="c",relx=0.5,rely=0.8)


  laiki = ['8:00', '10:00', '12:00', '14:00', '16:00', '18:00']
  svar = tk.StringVar()
  svar.set(laiki[0])
  sv = laiki[0]
  def _get(cur):  
    global sv  
    sv = cur          
  drop = tk.OptionMenu(window, svar, command = _get, *laiki)
  drop.place(anchor="c",relx=0.5,rely=0.65)

def frizieri_spec():
  for widgets in window.winfo_children():
        widgets.destroy()
  tips=tk.Label(window, text="Izvēlieties speciālistu").place(anchor="c",relx=0.5,rely=0.1)
  izv1 = tk.Button(window, text="Maija",command=forma,width=10).place(anchor="c",relx=0.5,rely=0.2)
  izv1 = tk.Button(window, text="Juris",command=forma,width=10).place(anchor="c",relx=0.5,rely=0.3)

def masieri_spec():
  for widgets in window.winfo_children():
        widgets.destroy()
  tips=tk.Label(window, text="Izvēlieties speciālistu").place(anchor="c",relx=0.5,rely=0.1)
  izv1 = tk.Button(window, text="Tālis",command=forma,width=10).place(anchor="c",relx=0.5,rely=0.2)
  izv1 = tk.Button(window, text="Mirdza",command=mirdza,width=10).place(anchor="c",relx=0.5,rely=0.3)


def v_pakal():
  for widgets in window.winfo_children():
        widgets.destroy()
  tips=tk.Label(window, text="Izvēlieties pakalpojuma tipu").place(anchor="c",relx=0.5,rely=0.1)
  izv1 = tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.2)
  medus=tk.Label(window, text="Matu kontūras veidošana- 10€").place(anchor="w",relx=0.05,rely=0.2)
  izv2= tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.3)
  speka=tk.Label(window, text="Matu noskūšana- 10€").place(anchor="w",relx=0.05,rely=0.3)
  izv3= tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.4)
  sokolades=tk.Label(window, text="Matu krāsošana- no 10€").place(anchor="w",relx=0.05,rely=0.4)


def s_pakal():
  for widgets in window.winfo_children():
        widgets.destroy()
  tips=tk.Label(window, text="Izvēlieties pakalpojuma tipu").place(anchor="c",relx=0.5,rely=0.1)
  izv1 = tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.2)
  griez=tk.Label(window, text="Matu griešana- 10€").place(anchor="w",relx=0.05,rely=0.2)
  izv2= tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.3)
  kr_griez=tk.Label(window, text="Matu griešana un krāsošana-\n no 20€").place(anchor="w",relx=0.05,rely=0.3)
  izv3= tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.4)
  pieaud=tk.Label(window, text="Matu pieaudzēšana- no 10€").place(anchor="w",relx=0.05,rely=0.4)

def b_pakal():
  for widgets in window.winfo_children():
        widgets.destroy()
  tips=tk.Label(window, text="Izvēlieties pakalpojuma tipu").place(anchor="c",relx=0.5,rely=0.1)
  medus=tk.Label(window, text="Matu noskūšana- 10€").place(anchor="w",relx=0.05,rely=0.2)
  izv1= tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.2)
  speka=tk.Label(window, text="Matu apgriešana- 10€").place(anchor="w",relx=0.05,rely=0.3)
  izv3= tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.3)
  izv3= tk.Button(window, text="Izvēlēties",command=frizieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.4)
  sokolades=tk.Label(window, text="Matu šķipsnu krāsošana- 5€").place(anchor="w",relx=0.05,rely=0.4)

def frizieri():
  for widgets in window.winfo_children():
        widgets.destroy()
  tips=tk.Label(window, text="Izvēlieties pakalpojuma tipu").place(anchor="c",relx=0.5,rely=0.1)
  sieviesu = tk.Button(window, text="Sieviešu",command=s_pakal,width=10).place(anchor="c",relx=0.5,rely=0.2)
  viriesu= tk.Button(window, text="Vīriešu",command=v_pakal,width=10).place(anchor="c",relx=0.5,rely=0.3)
  bernu= tk.Button(window, text="Bērnu",command=b_pakal,width=10).place(anchor="c",relx=0.5,rely=0.4)

def masaza():
  for widgets in window.winfo_children():
        widgets.destroy()
  tips=tk.Label(window, text="Izvēlieties pakalpojuma tipu").place(anchor="c",relx=0.5,rely=0.1)
  izv1 = tk.Button(window, text="Izvēlēties",command=masieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.2)
  medus=tk.Label(window, text="Medus masāža- 20€").place(anchor="w",relx=0.05,rely=0.2)
  izv2= tk.Button(window, text="Izvēlēties",command=masieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.3)
  speka=tk.Label(window, text="Spēka masāža- 25€").place(anchor="w",relx=0.05,rely=0.3)
  izv3= tk.Button(window, text="Izvēlēties",command=masieri_spec,width=7).place(anchor="c",relx=0.8,rely=0.4)
  sokolades=tk.Label(window, text="Šokolādes masāža- 35€").place(anchor="w",relx=0.05,rely=0.4)

def clicked():
  for widgets in window.winfo_children():
        widgets.destroy()
  pakalpojumi = tk.Label(text="Izvēlieties pakalpojumu").place(anchor="c",relx=0.5,rely=0.1)
  frizieris = tk.Button(window, text="Frizieris",command=frizieri,width=10).place(anchor="c",relx=0.5,rely=0.2)
  masieris= tk.Button(window, text="Masieris",command=masaza,width=10).place(anchor="c",relx=0.5,rely=0.3)
  
def forma():
  for widgets in window.winfo_children():
        widgets.destroy()
  a = tk.Label(window ,text = "Vārds").place(anchor="w",relx=0.05,rely=0.1)
  b = tk.Label(window ,text = "Uzvārds").place(anchor="w",relx=0.05,rely=0.2)
  c = tk.Label(window ,text = "Telefona numurs").place(anchor="w",relx=0.05,rely=0.3)
  d = tk.Label(window ,text = "E-Pasts").place(anchor="w",relx=0.05,rely=0.4)
  a1 = tk.Entry(window).place(anchor="c",relx=0.62,rely=0.1,width=150)
  b1 = tk.Entry(window).place(anchor="c",relx=0.62,rely=0.2,width=150)
  c1 = tk.Entry(window).place(anchor="c",relx=0.62,rely=0.3,width=150)
  d1 = tk.Entry(window).place(anchor="c",relx=0.62,rely=0.4,width=150)
  atpakal=tk.Button(window, text="< Atpakaļ",command=clicked).place(anchor="c",relx=0.3,rely=0.5)
  talak=tk.Button(window, text="Tālāk >").place(anchor="c",relx=0.7,rely=0.5)

hello = tk.Label(text="Sveicināti!").place(anchor="c",relx=0.5,rely=0.1)
hello1 = tk.Label(text="  Mūsu salona darba laiks ir Pr.- Pk. 8:00-18:00").place(anchor="c",relx=0.5,rely=0.15)
button = tk.Button(window, text="Veikt pierakstu",command=clicked).place(anchor="c",relx=0.5,rely=0.25)
tk.mainloop()